fx_version "bodacious"
game "gta5"
lua54 "yes"

server_scripts {
	"@vrp/lib/Utils.lua",
	"server-side/*"
}

file "config.json"