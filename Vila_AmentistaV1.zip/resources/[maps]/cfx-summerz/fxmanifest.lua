fx_version "cerulean"
game "gta5"

this_is_a_map "yes"

files {
	"stream/*",
	"stream/**/*",
	"interiorproxies.meta"
}

data_file "DLC_ITYP_REQUEST" "stream/*.ytyp"
data_file "DLC_ITYP_REQUEST" "stream/**/*.ytyp"
data_file "INTERIOR_PROXY_ORDER_FILE" "interiorproxies.meta"