fx_version "cerulean"
game "gta5"
lua54 "yes"

files {
	"stream/*",
	"stream/**/*",
	"stream/**/**/*",
	"weaponarchetypes.meta",
	"weaponcomponents.meta"
}

data_file "WEAPON_METADATA_FILE" "weaponarchetypes.meta"
data_file "WEAPONCOMPONENTSINFO_FILE" "weaponcomponents.meta"