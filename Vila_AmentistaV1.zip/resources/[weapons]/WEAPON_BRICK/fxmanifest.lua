fx_version "cerulean"
game "gta5"
lua54 "yes"

files {
	"pedpersonality.meta",
	"weaponanimations.meta",
	"weaponarchetypes.meta",
	"weapons_brick.meta"
}

data_file "PED_PERSONALITY_FILE" "pedpersonality.meta"
data_file "WEAPON_ANIMATIONS_FILE" "weaponanimations.meta"
data_file "WEAPON_METADATA_FILE" "weaponarchetypes.meta"
data_file "WEAPONINFO_FILE" "weapons_brick.meta"
data_file "WEAPONINFO_FILE_PATCH" "weapons_brick.meta"