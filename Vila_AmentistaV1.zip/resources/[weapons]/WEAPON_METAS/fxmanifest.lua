fx_version "cerulean"
game "gta5"
lua54 "yes"

files {
	"data-side/*.meta"
}

data_file "WEAPONINFO_FILE" "data-side/*.meta"
data_file "WEAPONINFO_FILE_PATCH" "data-side/*.meta"